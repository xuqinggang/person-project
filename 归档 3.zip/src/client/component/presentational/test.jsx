import React from 'react';

export default class Test extends React.Component {
	render() {
		return (
			<div>Test123</div>
		)
	}
}