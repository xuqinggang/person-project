import React from 'react';

import Test from 'component/presentational/test.jsx';
import 'assets/styles/index.scss';
export default class App extends React.Component {
	render() {
		return (
			<div>x1x12222211xx212211223311hello12343135455785660077, word</div>
		)
	}
}