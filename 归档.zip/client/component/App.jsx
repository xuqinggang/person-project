import React from 'react$';

import '../assets/styles/index.scss';
export default class App extends React.Component {
	render() {
		return (
			<div>hello123431, word</div>
		)
	}
}