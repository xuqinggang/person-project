
const server_config = {
	ismorphic: true,
	__dirname: process.cwd() // project root directory

};

export default server_config;