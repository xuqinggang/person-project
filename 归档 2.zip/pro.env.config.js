import path from 'path';


const dev_env_config = {
	node_modules_path: path.join(paprocess.cwd(), node_modules)
};


export default dev_env_config;