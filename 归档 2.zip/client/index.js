import React from 'react$';
import ReactDOM from 'react-dom$';
import { Provider } from 'react-redux';
import { browserHistory } from 'react-router';

import router from 'component/router.jsx';
import App from 'component/App.jsx';
console.log('2211xx1111asd222sdaff11122331231122xx11');

ReactDOM.render(
        <App>
        </App>
, document.getElementById('container'));

module.hot.accept();